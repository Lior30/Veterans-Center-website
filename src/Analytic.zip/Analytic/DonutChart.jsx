// src/components/DonutChart.jsx
import React from 'react';
import { ResponsivePie } from '@nivo/pie';

export default function DonutChart({ title, data }) {
  return (
    <div style={{ width: 200, height: 200 }}>
      <ResponsivePie
        data={data}
        margin={{ top: 10, right: 10, bottom: 10, left: 10 }}
        innerRadius={0.6}
        padAngle={0.7}
        cornerRadius={3}
        colors={{ scheme: 'category10' }}
        enableSlicesLabels={false}
        arcLinkLabelsSkipAngle={10}
        arcLinkLabelsTextColor="#333"
        arcLinkLabelsThickness={2}
        arcLinkLabelsColor={{ from: 'color' }}
      />
      <div style={{ textAlign: 'center', marginTop: '6px', fontWeight: 'bold' }}>
        {title}
      </div>
    </div>
  );
}
