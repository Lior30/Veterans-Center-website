
import React from "react";
// ... שאר הייבואות של nivo וכו'

export default function MultiRingChart({ data }) {
}