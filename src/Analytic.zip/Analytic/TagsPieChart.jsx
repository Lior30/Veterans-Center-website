import React, { useMemo } from 'react';
import { ResponsivePie } from '@nivo/pie';
import { useEffect, useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../firebase';

/**
 * TagsPieChart
 *
 * Props:
 * - activities: Array<{
 *     tag: string,
 *     registrations: number,
 *   }>
 */
export default function TagsPieChart({ activities = []}) {
  const PIE_COLORS = [
  '#7e64e0', // סגול בסיס
  '#3de2da', // טורקיז
  '#ffe87e', // צהוב-פסטל
  '#ff9d02', // כתום-אפרסק
  '#00b7ff', // תכלת
  '#d7c4ff', // סגול בהיר
  '#4e2fa7'  // סגול כהה
];

 const pieData = useMemo(() => {
    const byTag = {};

    activities.forEach(({ tag, participants = 0, capacity = 0 }) => {
      if (!byTag[tag])
        byTag[tag] = { participants: 0, capacity: 0 };

      byTag[tag].participants += participants;
      byTag[tag].capacity     += capacity;
    });

    /* המרה למערך */
    const items = Object.entries(byTag).map(
      ([tag, { participants, capacity }]) => ({
        id:    tag,
        label: tag,
        value: participants, // יחס או סה״כ
        participants,
        capacity,
      })
    );

    return items;
  }, [activities]);

  if (!pieData.length) {
    return <p style={{ textAlign: 'center' }}>אין נתונים להצגה</p>;
  }

return (
  <div style={{ height: 300, display: 'flex' }}>
    {/* ─────────── תרשים עוגה ─────────── */}
    <div style={{ flex: 1 }}>
      <ResponsivePie
        data={pieData}
        margin={{ top: 10, right: 10, bottom: 10, left: 10 }}
        innerRadius={0}
        padAngle={0.5}
        cornerRadius={3}
        colors={PIE_COLORS}
        borderWidth={1}
        borderColor={{ from: 'color', modifiers: [['darker', 0.2]] }}
        enableArcLabels={false}
        enableSliceLabels={false}    
        enableArcLinkLabels={false}
        arcLabel={() => ''}
        sliceLabel={() => ''}
        valueFormat={v =>
          typeof v === 'number'
            ? v <= 1
              ? `${(v * 100).toFixed(1)}%`
              : v.toFixed(1)
            : v
        }
        tooltip={({ datum }) => (
          <div style={{ padding: 8, direction: 'rtl' }}>
            <strong>{datum.label}</strong><br />
            {datum.data.participants}
            {datum.data.capacity ? ` / ${datum.data.capacity}` : ''}<br />
            {datum.value <= 1
              ? `${(datum.value * 100).toFixed(2)}%`
              : datum.value}
          </div>
        )}
      />
    </div>

    {/* ─────────── מקרא (עם גלילה אם יש הרבה תגיות) ─────────── */}
    <div
      style={{
        maxHeight: 260,
        overflowY: 'auto',
        padding: '4px 12px',
        display: 'flex',
        flexDirection: 'column',
        gap: 6,
        justifyContent: 'center'
      }}
    >
      {/* ← כאן חייבים סוגריים מסולסלים כדי להכניס ביטוי JSX */}
      {(() => {
        const total = pieData.reduce((s, d) => s + d.value, 0) || 1;
        const colors = [
          '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
          '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf'
        ];

        return pieData.map((item, idx) => (
          <div
            key={item.id}
            style={{ display: 'flex', alignItems: 'center', gap: 6 }}
          >
            <span
              style={{
                width: 14,
                height: 14,
                borderRadius: '50%',
                backgroundColor: colors[idx % colors.length],
                flexShrink: 0
              }}
            />
            <span style={{ fontSize: 13, color: '#495057', direction: 'rtl' }}>
              {item.label}<br />
              {(item.value / total * 100).toFixed(2)}%
            </span>
          </div>
        ));
      })()}
    </div>
  </div>
);


}